<?php

require_once(FRAME_WORK_PATH.'basic_classes/ModelSQL.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLInt.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLString.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLFloat.php');

class ReceiptPaymentTypeList_Model extends ModelSQL{
	
	public function __construct($dbLink){
		parent::__construct($dbLink);
		
		$this->setDbName("public");
		
		$this->setTableName("receipt_payment_types_list");
		
		$f_dt=new FieldSQlString($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"dt"
		,array(
		
			'primaryKey'=>TRUE,
			'id'=>"dt"
				
		
		));
		$this->addField($f_dt);

		$f_kkm_type_close=new FieldSQlInt($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"kkm_type_close"
		,array(
		
			'id'=>"kkm_type_close"
				
		
		));
		$this->addField($f_kkm_type_close);

		$f_payment_type_for_sale_id=new FieldSQlInt($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"payment_type_for_sale_id"
		,array(
		
			'id'=>"payment_type_for_sale_id"
				
		
		));
		$this->addField($f_payment_type_for_sale_id);

		$f_payment_type_for_sale_descr=new FieldSQlString($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"payment_type_for_sale_descr"
		,array(
		
			'id'=>"payment_type_for_sale_descr"
				
		
		));
		$this->addField($f_payment_type_for_sale_descr);

		$f_total=new FieldSQlFloat($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"total"
		,array(
		
			'length'=>2,
			'id'=>"total"
				
		
		));
		$this->addField($f_total);

		$f_user_id=new FieldSQlInt($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"user_id"
		,array(
		
			'id'=>"user_id"
				
		
		));
		$this->addField($f_user_id);

		
		
		
	}

}
?>
