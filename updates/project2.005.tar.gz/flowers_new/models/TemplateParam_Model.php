<?php

require_once(FRAME_WORK_PATH.'basic_classes/ModelSQL.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLInt.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLText.php');
require_once(FRAME_WORK_PATH.'basic_classes/ModelOrderSQL.php');

class TemplateParam_Model extends ModelSQL{
	
	public function __construct($dbLink){
		parent::__construct($dbLink);
		
		$this->setDbName("public");
		
		$this->setTableName("template_params");
		
		$f_id=new FieldSQlInt($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"id"
		,array(
		
			'primaryKey'=>TRUE,
			'autoInc'=>TRUE,
			'id'=>"id"
				
		
		));
		$this->addField($f_id);

		$f_template=new FieldSQlText($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"template"
		,array(
		
			'id'=>"template"
				
		
		));
		$this->addField($f_template);

		$f_param=new FieldSQlText($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"param"
		,array(
		
			'id'=>"param"
				
		
		));
		$this->addField($f_param);

		$f_param_type=new FieldSQlText($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"param_type"
		,array(
		
			'id'=>"param_type"
				
		
		));
		$this->addField($f_param_type);

		$order = new ModelOrderSQL();		
		$this->setDefaultModelOrder($order);		
		
		$order->addField($f_template);

		$order->addField($f_param);

		
		
		
	}

}
?>
