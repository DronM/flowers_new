<?php

require_once(FRAME_WORK_PATH.'basic_classes/ModelSQL.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLInt.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLText.php');

class TemplateParamVal_Model extends ModelSQL{
	
	public function __construct($dbLink){
		parent::__construct($dbLink);
		
		$this->setDbName("public");
		
		$this->setTableName("template_param_vals");
		
		$f_id=new FieldSQlInt($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"id"
		,array(
		
			'primaryKey'=>TRUE,
			'autoInc'=>TRUE,
			'id'=>"id"
				
		
		));
		$this->addField($f_id);

		$f_template_param_id=new FieldSQlInt($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"template_param_id"
		,array(
		
			'id'=>"template_param_id"
				
		
		));
		$this->addField($f_template_param_id);

		$f_user_id=new FieldSQlInt($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"user_id"
		,array(
		
			'alias'=>"Пользователь"
		,
			'id'=>"user_id"
				
		
		));
		$this->addField($f_user_id);

		$f_val=new FieldSQlText($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"val"
		,array(
		
			'id'=>"val"
				
		
		));
		$this->addField($f_val);

		
		
		
	}

}
?>
