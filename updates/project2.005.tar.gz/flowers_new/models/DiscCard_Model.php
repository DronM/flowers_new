<?php

require_once(FRAME_WORK_PATH.'basic_classes/ModelSQL.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLInt.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLText.php');

class DiscCard_Model extends ModelSQL{
	
	public function __construct($dbLink){
		parent::__construct($dbLink);
		
		$this->setDbName("public");
		
		$this->setTableName("disc_cards");
		
		$f_id=new FieldSQlInt($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"id"
		,array(
		'required'=>FALSE,
			'primaryKey'=>TRUE,
			'autoInc'=>TRUE,
			'alias'=>"Код"
		,
			'id'=>"id"
				
		
		));
		$this->addField($f_id);

		$f_discount_id=new FieldSQlInt($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"discount_id"
		,array(
		
			'alias'=>"Вид скидки"
		,
			'id'=>"discount_id"
				
		
		));
		$this->addField($f_discount_id);

		$f_barcode=new FieldSQlText($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"barcode"
		,array(
		
			'alias'=>"Штрихкод"
		,
			'id'=>"barcode"
				
		
		));
		$this->addField($f_barcode);

		
		
		
	}

}
?>
