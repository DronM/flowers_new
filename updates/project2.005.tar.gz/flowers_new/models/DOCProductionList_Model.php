<?php

require_once(FRAME_WORK_PATH.'basic_classes/ModelSQLDOC20.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLInt.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLString.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLText.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLFloat.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLDateTime.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLBool.php');

class DOCProductionList_Model extends ModelSQLDOC20{
	
	public function __construct($dbLink){
		parent::__construct($dbLink);
		
		$this->setDbName("public");
		
		$this->setTableName("doc_productions_list_view");
		
		$f_id=new FieldSQlInt($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"id"
		,array(
		
			'primaryKey'=>TRUE,
			'id'=>"id"
		,
			'sysCol'=>TRUE
				
		
		));
		$this->addField($f_id);

		$f_number=new FieldSQlString($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"number"
		,array(
		
			'alias'=>"Номер"
		,
			'id'=>"number"
				
		
		));
		$this->addField($f_number);

		$f_date_time=new FieldSQlDateTime($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"date_time"
		,array(
		
			'alias'=>"Дата"
		,
			'id'=>"date_time"
		,
			'sysCol'=>TRUE
				
		
		));
		$this->addField($f_date_time);

		$f_processed=new FieldSQlString($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"processed"
		,array(
		
			'alias'=>"Проведен"
		,
			'id'=>"processed"
				
		
		));
		$this->addField($f_processed);

		$f_on_norm=new FieldSQlBool($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"on_norm"
		,array(
		
			'alias'=>"По норме"
		,
			'id'=>"on_norm"
				
		
		));
		$this->addField($f_on_norm);

		$f_store_id=new FieldSQlInt($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"store_id"
		,array(
		
			'id'=>"store_id"
		,
			'sysCol'=>TRUE
				
		
		));
		$this->addField($f_store_id);

		$f_store_descr=new FieldSQlString($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"store_descr"
		,array(
		
			'alias'=>"Салон"
		,
			'id'=>"store_descr"
				
		
		));
		$this->addField($f_store_descr);

		$f_user_id=new FieldSQlInt($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"user_id"
		,array(
		
			'id'=>"user_id"
		,
			'sysCol'=>TRUE
				
		
		));
		$this->addField($f_user_id);

		$f_user_descr=new FieldSQlString($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"user_descr"
		,array(
		
			'alias'=>"Автор"
		,
			'id'=>"user_descr"
				
		
		));
		$this->addField($f_user_descr);

		$f_product_id=new FieldSQlInt($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"product_id"
		,array(
		
			'id'=>"product_id"
		,
			'sysCol'=>TRUE
				
		
		));
		$this->addField($f_product_id);

		$f_product_descr=new FieldSQlString($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"product_descr"
		,array(
		
			'alias'=>"Продукция"
		,
			'id'=>"product_descr"
				
		
		));
		$this->addField($f_product_descr);

		$f_quant=new FieldSQlFloat($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"quant"
		,array(
		
			'alias'=>"Количество"
		,
			'length'=>19,
			'id'=>"quant"
				
		
		));
		$this->addField($f_quant);

		$f_price=new FieldSQlFloat($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"price"
		,array(
		
			'alias'=>"Цена"
		,
			'length'=>15,
			'id'=>"price"
				
		
		));
		$this->addField($f_price);

		$f_material_retail_cost=new FieldSQlFloat($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"material_retail_cost"
		,array(
		
			'alias'=>"Сумма материалов"
		,
			'length'=>15,
			'id'=>"material_retail_cost"
				
		
		));
		$this->addField($f_material_retail_cost);

		$f_material_cost=new FieldSQlFloat($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"material_cost"
		,array(
		
			'alias'=>"Себестоимость материалов"
		,
			'length'=>15,
			'id'=>"material_cost"
				
		
		));
		$this->addField($f_material_cost);

		$f_income_percent=new FieldSQlFloat($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"income_percent"
		,array(
		
			'alias'=>"Наценка,%"
		,
			'length'=>15,
			'id'=>"income_percent"
				
		
		));
		$this->addField($f_income_percent);

		$f_income=new FieldSQlFloat($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"income"
		,array(
		
			'alias'=>"Наценка,руб"
		,
			'length'=>15,
			'id'=>"income"
				
		
		));
		$this->addField($f_income);

		$f_florist_comment=new FieldSQlText($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"florist_comment"
		,array(
		
			'alias'=>"Комментарий"
		,
			'id'=>"florist_comment"
				
		
		));
		$this->addField($f_florist_comment);

		$f_after_prod_interval=new FieldSQlText($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"after_prod_interval"
		,array(
		
			'alias'=>"Период после продажи"
		,
			'id'=>"after_prod_interval"
				
		
		));
		$this->addField($f_after_prod_interval);

		$f_doc_descr=new FieldSQlString($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"doc_descr"
		,array(
		
			'alias'=>"Представление документа"
		,
			'id'=>"doc_descr"
				
		
		));
		$this->addField($f_doc_descr);
$this->limitConstant = 'doc_per_page_count';
		
		
		
	}

}
?>
