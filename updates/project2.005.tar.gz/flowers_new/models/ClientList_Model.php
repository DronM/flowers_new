<?php

require_once(FRAME_WORK_PATH.'basic_classes/ModelSQL.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLInt.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLString.php');

class ClientList_Model extends ModelSQL{
	
	public function __construct($dbLink){
		parent::__construct($dbLink);
		
		$this->setDbName("public");
		
		$this->setTableName("client_list_view");
		
		$f_id=new FieldSQlInt($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"id"
		,array(
		'required'=>FALSE,
			'primaryKey'=>TRUE,
			'autoInc'=>TRUE,
			'id'=>"id"
				
		
		));
		$this->addField($f_id);

		$f_name=new FieldSQlString($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"name"
		,array(
		'required'=>TRUE,
			'length'=>100,
			'id'=>"name"
				
		
		));
		$this->addField($f_name);

		$f_tel=new FieldSQlString($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"tel"
		,array(
		
			'alias'=>"Телефон"
		,
			'id'=>"tel"
				
		
		));
		$this->addField($f_tel);

		$f_disc_card_percent=new FieldSQlString($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"disc_card_percent"
		,array(
		
			'alias'=>"Скидка, %"
		,
			'id'=>"disc_card_percent"
				
		
		));
		$this->addField($f_disc_card_percent);

		$f_disc_card_id=new FieldSQlInt($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"disc_card_id"
		,array(
		
			'id'=>"disc_card_id"
				
		
		));
		$this->addField($f_disc_card_id);

		$f_discount_id=new FieldSQlInt($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"discount_id"
		,array(
		
			'id'=>"discount_id"
				
		
		));
		$this->addField($f_discount_id);
$this->limitConstant = 'doc_per_page_count';
		
		
		
	}

}
?>
