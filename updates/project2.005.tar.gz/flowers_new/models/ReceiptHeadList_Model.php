<?php

require_once(FRAME_WORK_PATH.'basic_classes/ModelSQL.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLInt.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLString.php');

class ReceiptHeadList_Model extends ModelSQL{
	
	public function __construct($dbLink){
		parent::__construct($dbLink);
		
		$this->setDbName("public");
		
		$this->setTableName("receipt_head_list");
		
		$f_client_id=new FieldSQlInt($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"client_id"
		,array(
		
			'id'=>"client_id"
				
		
		));
		$this->addField($f_client_id);

		$f_client_descr=new FieldSQlString($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"client_descr"
		,array(
		
			'id'=>"client_descr"
				
		
		));
		$this->addField($f_client_descr);

		$f_discount_id=new FieldSQlInt($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"discount_id"
		,array(
		
			'id'=>"discount_id"
				
		
		));
		$this->addField($f_discount_id);

		$f_discount_descr=new FieldSQlString($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"discount_descr"
		,array(
		
			'id'=>"discount_descr"
				
		
		));
		$this->addField($f_discount_descr);

		$f_doc_client_order_id=new FieldSQlInt($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"doc_client_order_id"
		,array(
		
			'id'=>"doc_client_order_id"
				
		
		));
		$this->addField($f_doc_client_order_id);

		$f_doc_client_order_descr=new FieldSQlString($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"doc_client_order_descr"
		,array(
		
			'id'=>"doc_client_order_descr"
				
		
		));
		$this->addField($f_doc_client_order_descr);

		$f_user_id=new FieldSQlInt($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"user_id"
		,array(
		
			'primaryKey'=>TRUE,
			'id'=>"user_id"
				
		
		));
		$this->addField($f_user_id);

		
		
		
	}

}
?>
