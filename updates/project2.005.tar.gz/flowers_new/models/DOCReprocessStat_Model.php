<?php

require_once(FRAME_WORK_PATH.'basic_classes/ModelSQL.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLInt.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLEnum.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLDateTime.php');

class DOCReprocessStat_Model extends ModelSQL{
	
	public function __construct($dbLink){
		parent::__construct($dbLink);
		
		$this->setDbName("public");
		
		$this->setTableName("doc_reprocess_stat");
		
		$f_start_time=new FieldSQlDateTime($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"start_time"
		,array(
		
			'id'=>"start_time"
				
		
		));
		$this->addField($f_start_time);

		$f_update_time=new FieldSQlDateTime($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"update_time"
		,array(
		
			'id'=>"update_time"
				
		
		));
		$this->addField($f_update_time);

		$f_end_time=new FieldSQlDateTime($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"end_time"
		,array(
		
			'id'=>"end_time"
				
		
		));
		$this->addField($f_end_time);

		$f_count_total=new FieldSQlInt($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"count_total"
		,array(
		
			'id'=>"count_total"
				
		
		));
		$this->addField($f_count_total);

		$f_count_done=new FieldSQlInt($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"count_done"
		,array(
		
			'id'=>"count_done"
				
		
		));
		$this->addField($f_count_done);

		$f_time_to_go=new FieldSQlInterval($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"time_to_go"
		,array(
		
			'id'=>"time_to_go"
				
		
		));
		$this->addField($f_time_to_go);

		$f_doc_id=new FieldSQlInt($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"doc_id"
		,array(
		
			'id'=>"doc_id"
				
		
		));
		$this->addField($f_doc_id);

		$f_doc_type=new FieldSQlEnum($this->getDbLink(),$this->getDbName(),$this->getTableName()
		,"doc_type"
		,array(
		
			'id'=>"doc_type"
				
		
		));
		$this->addField($f_doc_type);

		
		
		
	}

}
?>
