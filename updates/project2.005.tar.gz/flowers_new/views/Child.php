<?php
require_once(USER_VIEWS_PATH.'ViewBase.php');
require_once(USER_CONTROLLERS_PATH.'Constant_Controller.php');

class Child extends ViewBase{

	//no menu
	protected function addMenu(&$models){
	}
	
	public function write(ArrayObject &$models){
		//add templates
		
		parent::write($models);
	}	

}
?>
