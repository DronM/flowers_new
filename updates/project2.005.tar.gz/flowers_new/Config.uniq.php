<?php
/*Contstants unique to this server
*/

//host for js
define('BASE_PATH','http://localhost/flowers_new/');
//define('BASE_PATH','http://10.0.2.2/flowers_new/');

?>
