<?php

require_once(FRAME_WORK_PATH.'basic_classes/ControllerSQL.php');

require_once(FRAME_WORK_PATH.'basic_classes/FieldExtInt.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldExtString.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldExtFloat.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldExtEnum.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldExtText.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldExtDateTime.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldExtDate.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldExtTime.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldExtPassword.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldExtBool.php');
class DOCManager_Controller extends ControllerSQL{
	public function __construct($dbLinkMaster=NULL){
		parent::__construct($dbLinkMaster);
			
		$pm = new PublicMethod('reprocess');
		
		$this->addPublicMethod($pm);

		
	}	
	
	public function reprocess($pm){
		$l = $this->getDbLinkMaster();
		$l->query("DELETE FROM doc_reprocess_stat");
	
		$id = $l->query(
		"SELECT
			doc_type,
			doc_id,
			doc_table(doc_type) AS doc_table
		FROM doc_log
		ORDER BY date_time,id");
		
		$first = TRUE;
		$count_total = $l->num_rows();
		$count_done = 0;
		$percent_old = 0;
		while ($ar = $l->fetch_array($id)){
			if ($first){
				$l->query(sprintf(
				"INSERT INTO doc_reprocess_stat (start_time,update_time,count_total,count_done)
				VALUES (now(),now(),%d,0)",$count_total
				));			
				
				$first = FALSE;
			}
			else{
				$l->query(sprintf(
				"UPDATE doc_reprocess_stat
				SET
					time_to_go = ( ((count_total-count_done-1)*EXTRACT(epoch FROM now()-update_time)) || ' seconds')::interval,
					update_time = now(),
					count_done=%d,
					doc_id=%d,
					doc_type='%s'",
					$count_done,$ar['doc_id'],$ar['doc_type']
				));			
			
			}
			
			if ($ar['doc_table']=='doc_expences'){
				$count_done++;
				continue;
			}
			
			$l->query(sprintf("SELECT %s_act(%d)",$ar['doc_table'],$ar['doc_id']));
			//throw new Exception(sprintf("SELECT %s_act(%d)",$ar['doc_table'],$ar['doc_id']));
			
			$count_done++;
		}
		
		$l->query(sprintf(
		"UPDATE doc_reprocess_stat
		SET
			end_time = now()
			count_done=%d",$count_done
		));			
		
	}

}
?>
