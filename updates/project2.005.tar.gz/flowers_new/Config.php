<?php
/*absolute path to project*/
define('ABSOLUTE_PATH', dirname(__FILE__).'/');

/*Current php framwork version*/
define('FRAME_WORK_PATH', 'fw_20/');

/*current db server constants*/
require_once(ABSOLUTE_PATH.'../../postgres_srv.php');

/*Server unique configuration*/
require_once('Config.uniq.php');

/*Current version for js*/
require_once('version.php');

/*path to user controllers*/
define('USER_CONTROLLERS_PATH', ABSOLUTE_PATH.'controllers/');

/*path to user views*/
define('USER_VIEWS_PATH', ABSOLUTE_PATH.'views/');

/*path to user models*/
define('USER_MODELS_PATH', ABSOLUTE_PATH.'models/');

/*path to user functions*/
define('FUNC_PATH', ABSOLUTE_PATH.'functions/');

/*path to css*/
define('USER_CSS_PATH', 'css/');

/*path to js*/
define('USER_JS_PATH', 'js20/');

define('PARAM_CONTROLLER', 'c');
define('PARAM_METHOD', 'f');
define('PARAM_VIEW', 'v');

define('OUTPUT_PATH', ABSOLUTE_PATH.'output/');

/*Default View*/
define('DEF_VIEW', 'ViewBase');

//********************************************************************************
/*Db connection constants*/
define('DB_NAME', 'flowers');
define('DB_USER', 'bellagio');
define('DB_PASSWORD', '159753');

/*Application constants*/
define('APP_NAME', 'flowers_new');
define('DEBUG', TRUE);
define('TECH_EMAIL', 'katrenplus@mail.ru');
define('AUTHOR', 'Andrey Mikhalevich');

//********************************************************************************

/*Building constants*/
define('BUILD_GROUP', 'andrey');
define('BUILD_FILE_PERMISSION', '0664');
define('BUILD_DIR_PERMISSION', '0775');

define('GITHUB_USER','DronM');

?>
