/* Copyright (c) 2016
	Andrey Mikhalevich, Katren ltd.
*/
/*	
	Description
*/
/** Requirements
 * @requires core/extend.js
 * @requires core/ControllerDb.js
*/

/* constructor
@param string id
@param object options{

}
*/

function RepSalesOnTypes_Controller(app,options){
	options = options || {};
	RepSalesOnTypes_Controller.superclass.constructor.call(this,app,options);	
	
	//methods
	this.addGetObject();
	this.add_report();
		
}
extend(RepSalesOnTypes_Controller,ControllerDb);

			RepSalesOnTypes_Controller.prototype.addGetObject = function(){
	RepSalesOnTypes_Controller.superclass.addGetObject.call(this);
	var options = {};
	
	var pm = this.getGetObject();
}

			RepSalesOnTypes_Controller.prototype.add_report = function(){
	var pm = new PublicMethod('report',{controller:this});
	this.addPublicMethod(pm);
	
				
	
	var options = {};
	
		pm.addField(new FieldString("cond_fields",options));
	
				
	
	var options = {};
	
		pm.addField(new FieldString("cond_vals",options));
	
				
	
	var options = {};
	
		pm.addField(new FieldString("cond_sgns",options));
	
				
	
	var options = {};
	
		pm.addField(new FieldString("cond_ic",options));
	
				
	
	var options = {};
	
		pm.addField(new FieldString("templ",options));
	
				
	
	var options = {};
	
		pm.addField(new FieldString("ord_fields",options));
	
				
	
	var options = {};
	
		pm.addField(new FieldString("ord_directs",options));
					
				
	
	var options = {};
	
		pm.addField(new FieldString("field_sep",options));
	
			
}
									
		