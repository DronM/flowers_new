/* Copyright (c) 2016 
	Andrey Mikhalevich, Katren ltd.
*/
/*	
	Description
*/
/** Requirements
 * @requires 
 * @requires core/extend.js  
*/

/* constructor
@param string id
@param object options{

}
*/
function EnumGridColumn_delivery_types(id,options){
	options = options || {};	
	
	options.multyLangValues = {
		"rus":{"courier":"курьер","by_client":"самовывоз"}
	};
	
	
	EnumGridColumn_delivery_types.superclass.constructor.call(this,id,options);
}
extend(EnumGridColumn_delivery_types,GridColumn);

/* Constants */


/* private members */

/* protected*/


/* public methods */

