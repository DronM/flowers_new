DOCCommands.prototype.CTRL_DETFILL_CAP = {"rus":"Подбор"};
DOCCommands.prototype.CTRL_DETFILL_TITLE = {"rus":"Открыть форму для множественного подбора"};

DOCProductionDetMatSysCell.prototype.BTN_INC_TITLE = {"rus":"Увеличить количество на 1"};
DOCProductionDetMatSysCell.prototype.BTN_DEC_TITLE = {"rus":"Уменьшить количество на 1"};
DOCProductionDetMatSysCell.prototype.BTN_DEL_TITLE = {"rus":"Удалить строку"};

PaymentTypeForSaleSelect.prototype.CAP = {"rus":"Вид оплаты:"};
DiscountSelect.prototype.CAP = {"rus":"Вид скидки:"};
