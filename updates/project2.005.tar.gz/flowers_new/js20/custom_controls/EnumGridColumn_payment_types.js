/* Copyright (c) 2016 
	Andrey Mikhalevich, Katren ltd.
*/
/*	
	Description
*/
/** Requirements
 * @requires 
 * @requires core/extend.js  
*/

/* constructor
@param string id
@param object options{

}
*/
function EnumGridColumn_payment_types(options){
	options = options || {};	
	
	options.multyLangValues = {
		"rus":{
			"cash":"Наличными"
			,"bank":"Банковской картой"
			,"yandex":"Яндекс деньги"
			,"trans_to_card":"Перевод на карту"
			,"web_money":"Web money"		
		}
	};
	
	EnumGridColumn_payment_types.superclass.constructor.call(this,options);
}
extend(EnumGridColumn_payment_types,GridColumnEnum);

/* Constants */


/* private members */

/* protected*/


/* public methods */

