/* Copyright (c) 2016
	Andrey Mikhalevich, Katren ltd.
*/
/*	
	Description
*/
/** Requirements
 * @requires core/extend.js
 * @requires controls/EditSelect.js
*/

/* constructor */

function Enum_def_date_types(id,options){
	options = options || {};
	options.addNotSelected = (options.addNotSelected!=undefined)? options.addNotSelected:true;
	var multy_lang_values = {"rus_cur_shift":"Текущая смена"
,"rus_cur_date":"Текущая дата"
,"rus_cur_week":"Текущая неделя"
,"rus_cur_month":"Текущий месяц"
,"rus_cur_quarter":"Текущий квартал"
,"rus_cur_year":"Текущий год"
};
	options.options = [{"value":"cur_shift",
"descr":multy_lang_values[options.app.getLang()+"_"+"cur_shift"],
checked:(options.defaultValue&&options.defaultValue=="cur_shift")}
,{"value":"cur_date",
"descr":multy_lang_values[options.app.getLang()+"_"+"cur_date"],
checked:(options.defaultValue&&options.defaultValue=="cur_date")}
,{"value":"cur_week",
"descr":multy_lang_values[options.app.getLang()+"_"+"cur_week"],
checked:(options.defaultValue&&options.defaultValue=="cur_week")}
,{"value":"cur_month",
"descr":multy_lang_values[options.app.getLang()+"_"+"cur_month"],
checked:(options.defaultValue&&options.defaultValue=="cur_month")}
,{"value":"cur_quarter",
"descr":multy_lang_values[options.app.getLang()+"_"+"cur_quarter"],
checked:(options.defaultValue&&options.defaultValue=="cur_quarter")}
,{"value":"cur_year",
"descr":multy_lang_values[options.app.getLang()+"_"+"cur_year"],
checked:(options.defaultValue&&options.defaultValue=="cur_year")}
];
	
	Enum_role_types.superclass.constructor.call(this,id,options);
	
}
extend(Enum_def_date_types,EditSelect);

