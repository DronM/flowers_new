/* Copyright (c) 2016
	Andrey Mikhalevich, Katren ltd.
*/
/*	
	Description
*/
/** Requirements
 * @requires core/extend.js
 * @requires controls/EditSelect.js
*/

/* constructor */

function Enum_payment_types(id,options){
	options = options || {};
	options.addNotSelected = (options.addNotSelected!=undefined)? options.addNotSelected:true;
	var multy_lang_values = {"rus_cash":"Наличными"
,"rus_bank":"Банковской картой"
,"rus_yandex":"Яндекс деньги"
,"rus_trans_to_card":"Перевод на карту"
,"rus_web_money":"Web money"
};
	options.options = [{"value":"cash",
"descr":multy_lang_values[options.app.getLang()+"_"+"cash"],
checked:(options.defaultValue&&options.defaultValue=="cash")}
,{"value":"bank",
"descr":multy_lang_values[options.app.getLang()+"_"+"bank"],
checked:(options.defaultValue&&options.defaultValue=="bank")}
,{"value":"yandex",
"descr":multy_lang_values[options.app.getLang()+"_"+"yandex"],
checked:(options.defaultValue&&options.defaultValue=="yandex")}
,{"value":"trans_to_card",
"descr":multy_lang_values[options.app.getLang()+"_"+"trans_to_card"],
checked:(options.defaultValue&&options.defaultValue=="trans_to_card")}
,{"value":"web_money",
"descr":multy_lang_values[options.app.getLang()+"_"+"web_money"],
checked:(options.defaultValue&&options.defaultValue=="web_money")}
];
	
	Enum_role_types.superclass.constructor.call(this,id,options);
	
}
extend(Enum_payment_types,EditSelect);

