/* Copyright (c) 2016 
	Andrey Mikhalevich, Katren ltd.
*/
/*	
	Description
*/
/** Requirements
 * @requires core/extend.js
 * @requires core/App.js
*/

/* constructor */
function AppCRM(options){
	options = options || {};
	options.lang = "rus";
	
	this.setCachRegister(options.cashRegister);
	
	AppCRM.superclass.constructor.call(this,"CRM",options);
}
extend(AppCRM,App);

/* Constants */


/* private members */
AppCRM.prototype.m_cashRegister;

/* protected*/


/* public methods */
AppCRM.prototype.formatError = function(erCode,erStr){
	return (erStr +( (erCode)? (", код:"+erCode):"" ) );
}
AppCRM.prototype.getJournalDateFormat = function(){
	return "d/m/y, H:i:s";
}

AppCRM.prototype.setCachRegister = function(v){
	this.m_cashRegister = v;
}

AppCRM.prototype.getCachRegister = function(){
	return this.m_cashRegister;
}

AppCRM.prototype.getCachierPwd = function(){
	return "29";
}
AppCRM.prototype.getCachierAdminPwd = function(){
	return "30";
}

