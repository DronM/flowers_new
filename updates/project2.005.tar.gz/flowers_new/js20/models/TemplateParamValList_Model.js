/* Copyright (c) 2016
	Andrey Mikhalevich, Katren ltd.
*/
/*	
	Description
*/
/** Requirements
 * @requires core/extend.js
 * @requires core/ModelXML.js
*/

/* constructor
@param string id
@param object options{

}
*/

function TemplateParamValList_Model(options){
	var id = 'TemplateParamValList_Model';
	options = options || {};
	
	options.fields = {};
	
			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldString("param",filed_options);
	

	options.fields.param = field;

			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldText("val",filed_options);
	

	options.fields.val = field;

		TemplateParamValList_Model.superclass.constructor.call(this,id,options);
}
extend(TemplateParamValList_Model,ModelXML);

