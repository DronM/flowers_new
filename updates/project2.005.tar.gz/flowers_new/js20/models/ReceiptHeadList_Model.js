/* Copyright (c) 2016
	Andrey Mikhalevich, Katren ltd.
*/
/*	
	Description
*/
/** Requirements
 * @requires core/extend.js
 * @requires core/ModelXML.js
*/

/* constructor
@param string id
@param object options{

}
*/

function ReceiptHeadList_Model(options){
	var id = 'ReceiptHeadList_Model';
	options = options || {};
	
	options.fields = {};
	
			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldInt("client_id",filed_options);
	

	options.fields.client_id = field;

			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldString("client_descr",filed_options);
	

	options.fields.client_descr = field;

			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldInt("discount_id",filed_options);
	

	options.fields.discount_id = field;

			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldString("discount_descr",filed_options);
	

	options.fields.discount_descr = field;

			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldInt("doc_client_order_id",filed_options);
	

	options.fields.doc_client_order_id = field;

			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldString("doc_client_order_descr",filed_options);
	

	options.fields.doc_client_order_descr = field;

			
	var filed_options = {};
	filed_options.primaryKey = true;
	
	
	var field = new FieldInt("user_id",filed_options);
	

	options.fields.user_id = field;

		ReceiptHeadList_Model.superclass.constructor.call(this,id,options);
}
extend(ReceiptHeadList_Model,ModelXML);

