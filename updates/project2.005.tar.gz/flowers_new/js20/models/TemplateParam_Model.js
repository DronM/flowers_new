/* Copyright (c) 2016
	Andrey Mikhalevich, Katren ltd.
*/
/*	
	Description
*/
/** Requirements
 * @requires core/extend.js
 * @requires core/ModelXML.js
*/

/* constructor
@param string id
@param object options{

}
*/

function TemplateParam_Model(options){
	var id = 'TemplateParam_Model';
	options = options || {};
	
	options.fields = {};
	
			
				
				
							
		
			
	var filed_options = {};
	filed_options.primaryKey = true;
	
	
	var field = new FieldInt("id",filed_options);
	

	options.fields.id = field;

			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldText("template",filed_options);
	

	options.fields.template = field;

			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldText("param",filed_options);
	

	options.fields.param = field;

			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldText("param_type",filed_options);
	

	options.fields.param_type = field;

			
																		
		TemplateParam_Model.superclass.constructor.call(this,id,options);
}
extend(TemplateParam_Model,ModelXML);

