/* Copyright (c) 2016
	Andrey Mikhalevich, Katren ltd.
*/
/*	
	Description
*/
/** Requirements
 * @requires core/extend.js
 * @requires core/ModelXML.js
*/

/* constructor
@param string id
@param object options{

}
*/

function ReceiptPaymentTypeList_Model(options){
	var id = 'ReceiptPaymentTypeList_Model';
	options = options || {};
	
	options.fields = {};
	
			
	var filed_options = {};
	filed_options.primaryKey = true;
	
	
	var field = new FieldString("dt",filed_options);
	

	options.fields.dt = field;

			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldInt("kkm_type_close",filed_options);
	

	options.fields.kkm_type_close = field;

			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldInt("payment_type_for_sale_id",filed_options);
	

	options.fields.payment_type_for_sale_id = field;

			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldString("payment_type_for_sale_descr",filed_options);
	

	options.fields.payment_type_for_sale_descr = field;

			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldFloat("total",filed_options);
	
		field.getValidator().setMaxLength('2');
	

	options.fields.total = field;

			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldInt("user_id",filed_options);
	

	options.fields.user_id = field;

		ReceiptPaymentTypeList_Model.superclass.constructor.call(this,id,options);
}
extend(ReceiptPaymentTypeList_Model,ModelXML);

