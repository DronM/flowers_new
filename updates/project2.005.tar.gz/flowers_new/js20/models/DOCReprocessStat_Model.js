/* Copyright (c) 2016
	Andrey Mikhalevich, Katren ltd.
*/
/*	
	Description
*/
/** Requirements
 * @requires core/extend.js
 * @requires core/ModelXML.js
*/

/* constructor
@param string id
@param object options{

}
*/

function DOCReprocessStat_Model(options){
	var id = 'DOCReprocessStat_Model';
	options = options || {};
	
	options.fields = {};
	
			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldDateTime("start_time",filed_options);
	

	options.fields.start_time = field;

			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldDateTime("update_time",filed_options);
	

	options.fields.update_time = field;

			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldDateTime("end_time",filed_options);
	

	options.fields.end_time = field;

			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldInt("count_total",filed_options);
	

	options.fields.count_total = field;

			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldInt("count_done",filed_options);
	

	options.fields.count_done = field;
			
			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldInterval("time_to_go",filed_options);
	

	options.fields.time_to_go = field;

			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldInt("doc_id",filed_options);
	

	options.fields.doc_id = field;

			
	var filed_options = {};
	filed_options.primaryKey = false;
	
	
	var field = new FieldEnum("doc_type",filed_options);
	filed_options.enumValues = 'production,product_disposal,material_procurement,material_disposal,sale,expence,doc_client_order';
	

	options.fields.doc_type = field;

		DOCReprocessStat_Model.superclass.constructor.call(this,id,options);
}
extend(DOCReprocessStat_Model,ModelXML);

